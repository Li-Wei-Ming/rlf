import RNclustering_function as RNc
from RNclustering_function import Qc
from make_centroid import Centroid
import make_centroid as mcn
import torch as tc
import numpy as np

device = 'cuda:0'
k = 10
iterations = 270
nor_num = 512

base_trust, base = 1.2, 1.2
trust_rate = 0.65
batch_num = 150
batch_num_trust = 150
data_type = tc.float32
data_type_cul_trust = tc.float32
add_rate = 0.2
trust_rate_of_centroid = 0.4


img_train0, label_train0, img_test0, label_test0 = RNc.load_data()
img_train, img_test, lab_train, lab_test = RNc.feature_map(img_train0, img_test0, label_train0, label_test0, nor_num, data_type, device)

make_center = Centroid(img_test, lab_test, device)
centroid_tensor, centroid_tensor_label, train_set, train_set_label = make_center.__main__()

centroid_tensor_list, centroid_tensor_label_list = mcn.to_list(centroid_tensor, centroid_tensor_label)

a = Qc(train_set, train_set_label, centroid_tensor_list, centroid_tensor_label_list, data_type, device, batch_num, iterations, base, trust_rate,  add_rate, data_type_cul_trust, batch_num_trust, base_trust, trust_rate_of_centroid)
list_acu = a.__main__()



