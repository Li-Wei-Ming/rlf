import k_means_clustering as kmc
from k_means_clustering import K_means
import torch as tc
import numpy as np

batch_num = 4000
data_type = tc.float32
device = 'cuda'
iterations = 270

img_train, label_train, img_test, label_test = kmc.load_data()
img_train, img_test, label_train, label_test = kmc.make_tensor(img_train, img_test, label_train, label_test, device, data_type)
acu_list = []

centroid_tensor, centroid_tensor_label, train_set, train_set_label = kmc.choose_centorid_list(img_test, label_test)
a = K_means(train_set, train_set_label, centroid_tensor, centroid_tensor_label, data_type, device, batch_num, iterations)
a.__main__()

