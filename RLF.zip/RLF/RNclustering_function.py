import torch as tc
import numpy as np
from random import sample
import copy
import os
import gzip
# import matplotlib
# import matplotlib.pyplot as plt
import time
from scipy.optimize import linear_sum_assignment


class Qc(object):
    def __init__(self, train_set, train_set_label, centroid_tensor_list, centroid_tensor_label_list, data_type, device, batch_num, iterations, base, trust_rate, add_rate, data_type_cul_trust, batch_num_trust, base_trust, trust_rate_of_centroid):
        self.train_set = train_set
        self.device = device
        self.iterations = iterations
        self.train_set_label = train_set_label
        self.centroid_tensor_list = centroid_tensor_list
        self.centroid_tensor_label_list = centroid_tensor_label_list
        self.label_predict = tc.zeros_like(train_set_label)
        self.all_num = centroid_tensor_list[0].shape[0]*10 + train_set.shape[0]
        self.mean = True

        self.rate = add_rate
        self.data_type = data_type
        self.batch_num = batch_num
        self.base = base
        self.trust_rate = trust_rate

        self.data_type = data_type
        self.batch_num = batch_num
        self.base = base

        self.data_type_cul_trust = data_type_cul_trust
        self.batch_num_trust = batch_num_trust
        self.base_trust = base_trust

        self.trust_rate_of_centroid = trust_rate_of_centroid

    def cul_distance(self):
        total_num = self.train_set.shape[0]
        circle_num = total_num // self.batch_num
        yushu = total_num % self.batch_num
        if yushu != 0:
            inner_product = tc.zeros((len(self.centroid_tensor_list), total_num - yushu), dtype=self.data_type, device=self.device)
            for i in range(circle_num):
                for ii in range(len(self.centroid_tensor_list)):
                    inner_product0 = tc.einsum('nld, mld-> nml', [self.train_set[(i * self.batch_num):(i + 1) * self.batch_num, :, :], self.centroid_tensor_list[ii]])
                    inner_product[ii:, (i * self.batch_num):(i + 1) * self.batch_num] = tc.einsum('nm-> n', [self.base ** tc.einsum('nml-> nm', [tc.log10(inner_product0 + 1e-7)])])/self.centroid_tensor_list[ii].shape[0]
            yushu_tensor = tc.zeros((len(self.centroid_tensor_list), yushu), dtype=self.data_type, device=self.device)
            for iii in range(len(self.centroid_tensor_list)):
                inner_product00 = tc.einsum('nld, mld-> nml', [self.train_set[(total_num - yushu):, :, :], self.centroid_tensor_list[iii]])
                inner_product_yushu = tc.einsum('nm-> n', [self.base ** tc.einsum('nml-> nm', [tc.log10(inner_product00 + 1e-7)])])/self.centroid_tensor_list[iii].shape[0]
                yushu_tensor[iii, :] = inner_product_yushu
            inner_product = tc.cat((inner_product, yushu_tensor), dim=1)
        else:
            inner_product = tc.zeros((len(self.centroid_tensor_list), total_num), dtype=self.data_type, device=self.device)
            for i in range(circle_num):
                for ii in range(len(self.centroid_tensor_list)):
                    inner_product0 = tc.einsum('nld, mld-> nml', [self.train_set[(i * self.batch_num):(i + 1) * self.batch_num, :, :], self.centroid_tensor_list[ii]])
                    inner_product[ii:, (i * self.batch_num):(i + 1) * self.batch_num] = tc.einsum('nm-> n', [self.base ** tc.einsum('nml-> nm', [tc.log10(inner_product0 + 1e-7)])])/self.centroid_tensor_list[ii].shape[0]
        self.label_predict = tc.argmax(inner_product, dim=0)

    def cul_inner_product(self, known_picture_list, unknown_picture):
        total_num = unknown_picture.shape[0]
        circle_num = total_num // self.batch_num_trust
        yushu = total_num % self.batch_num_trust
        if yushu != 0:
            inner_product = tc.zeros((len(known_picture_list), total_num - yushu), dtype=self.data_type_cul_trust, device=self.device)
            for i in range(circle_num):
                for ii in range(len(known_picture_list)):
                    inner_product0 = tc.einsum('nld, mld-> nml', [unknown_picture[(i * self.batch_num_trust):(i + 1) * self.batch_num_trust, :, :], known_picture_list[ii]])
                    inner_product[ii:, (i * self.batch_num_trust):(i + 1) * self.batch_num_trust] = tc.einsum('nm-> n', [self.base_trust ** tc.einsum('nml-> nm', [tc.log10(inner_product0 + 1e-7)])])

            yushu_tensor = tc.zeros((len(known_picture_list), yushu), dtype=self.data_type_cul_trust, device=self.device)
            for iii in range(len(known_picture_list)):
                inner_product00 = tc.einsum('nld, mld-> nml', [unknown_picture[(total_num - yushu):, :, :], known_picture_list[iii]])
                inner_product_yushu = tc.einsum('nm-> n', [self.base_trust ** tc.einsum('nml-> nm', [tc.log10(inner_product00 + 1e-7)])])
                yushu_tensor[iii, :] = inner_product_yushu
            inner_product = tc.cat((inner_product, yushu_tensor), dim=1)
        else:
            inner_product = tc.zeros((len(known_picture_list), total_num), dtype=self.data_type_cul_trust, device=self.device)
            for i in range(circle_num):
                for ii in range(len(known_picture_list)):
                    inner_product0 = tc.einsum('nld, mld-> nml', [unknown_picture[(i * self.batch_num_trust):(i + 1) * self.batch_num_trust, :, :], known_picture_list[ii]])
                    inner_product[ii:, (i * self.batch_num_trust):(i + 1) * self.batch_num_trust] = tc.einsum('nm-> n', [self.base_trust ** tc.einsum('nml-> nm', [tc.log10(inner_product0 + 1e-7)])])
        return inner_product

    def distribution_image_to_cluster(self):
        print('allocation')
        for i in range(len(self.centroid_tensor_list)):
            a = copy.deepcopy(self.label_predict)
            self.centroid_tensor_list[i] = tc.cat((self.centroid_tensor_list[i], self.train_set[a == i]), dim=0)
            self.centroid_tensor_label_list[i] = tc.cat((self.centroid_tensor_label_list[i], self.train_set_label[a == i]))
        self.train_set = tc.zeros((1, 784, 2), dtype=self.data_type, device=self.device)  # 用作连接
        self.train_set_label = tc.zeros(1, dtype=tc.long, device=self.device)

    def update_centroid_tensor_list_with_trust_rate(self):

        print('update')
        trust_rate_list = []

        for k in range(len(self.centroid_tensor_list)):
            inner_product = Qc.cul_inner_product(self, self.centroid_tensor_list, self.centroid_tensor_list[k])
            for i in range(len(self.centroid_tensor_list)):
                if i == k:
                    inner_product[i, :] = (inner_product[i, :] - 1) / (self.centroid_tensor_list[i].shape[0] - 1)
                else:
                    inner_product[i, :] = inner_product[i, :] / self.centroid_tensor_list[i].shape[0]
            trust_rate = inner_product[k, :] / tc.sum(inner_product, dim=0)
            trust_rate_list.append(trust_rate)
        for k in range(len(self.centroid_tensor_list)):
            trust_rate0 = trust_rate_list[k]
            if trust_rate0.shape[0] > int(self.all_num * 0.14):
                trust_num = int(trust_rate0.shape[0] * (self.trust_rate - self.rate))
            elif trust_rate0.shape[0] < int(self.all_num * 0.06):
                trust_num = int(trust_rate0.shape[0] * (self.trust_rate + self.rate))
            else:
                trust_num = int(trust_rate0.shape[0]*self.trust_rate)
            remain_index = tc.topk(trust_rate0, trust_num, dim=0, largest=True)[1]
            delete_index = tc.topk(trust_rate0, trust_rate0.shape[0] - trust_num, dim=0, largest=False)[1]
            self.train_set = tc.cat((self.train_set, (self.centroid_tensor_list[k])[delete_index]), dim=0)
            self.train_set_label = tc.cat((self.train_set_label, (self.centroid_tensor_label_list[k])[delete_index]), dim=0)
            self.centroid_tensor_list[k] = (self.centroid_tensor_list[k])[remain_index]
            self.centroid_tensor_label_list[k] = (self.centroid_tensor_label_list[k])[remain_index]
        self.train_set = self.train_set[1:, :, :]
        self.train_set_label = self.train_set_label[1:]
        Qc.cul_distance(self)

    def update_centroid_tensor_list(self):
        trust_rate_list = []
        for k in range(len(self.centroid_tensor_list)):
            inner_product = Qc.cul_inner_product(self, self.centroid_tensor_list, self.centroid_tensor_list[k])
            for i in range(len(self.centroid_tensor_list)):
                if i == k:
                    inner_product[i, :] = (inner_product[i, :] - 1) / (self.centroid_tensor_list[i].shape[0] - 1)
                else:
                    inner_product[i, :] = inner_product[i, :] / self.centroid_tensor_list[i].shape[0]
            trust_rate = inner_product[k, :] / tc.sum(inner_product, dim=0)
            trust_rate_list.append(trust_rate)
        for k in range(len(self.centroid_tensor_list)):
            trust_rate0 = trust_rate_list[k]
            trust_num = int(trust_rate0.shape[0] * self.trust_rate_of_centroid)
            remain_index = tc.topk(trust_rate0, trust_num, dim=0, largest=True)[1]
            delete_index = tc.topk(trust_rate0, trust_rate0.shape[0] - trust_num, dim=0, largest=False)[1]
            self.train_set = tc.cat((self.train_set, (self.centroid_tensor_list[k])[delete_index]), dim=0)
            self.train_set_label = tc.cat((self.train_set_label, (self.centroid_tensor_label_list[k])[delete_index]), dim=0)
            self.centroid_tensor_list[k] = (self.centroid_tensor_list[k])[remain_index]
            self.centroid_tensor_label_list[k] = (self.centroid_tensor_label_list[k])[remain_index]

    def cul_accuracy_assignment(self):
        print('cul_acc')
        acu_list = []
        num_list = []
        index_list = []
        np_label_pred = np.array(self.label_predict.cpu(), dtype=np.long)
        np_label = np.array(self.train_set_label.cpu(), dtype=np.long)
        for k in range(len(self.centroid_tensor_list)):
            np_label_pred = np.concatenate((np_label_pred, np.full_like(self.centroid_tensor_label_list[k].cpu(), k)),axis=0)
            np_label = np.concatenate((np_label, np.array(self.centroid_tensor_label_list[k].cpu(), dtype=np.long)),axis=0)
        num = np.zeros((10, 10))
        for i in range(len(self.centroid_tensor_list)):
            x = np.squeeze(np_label[np_label_pred == i])
            index_list.append(np.argmax(np.bincount(x)))
            for ii in range(10):
                num[i, ii] = 1/(np.sum((x == ii)) + 1e-18)
            num_list.append(x.shape[0])
        assignment_index = list(linear_sum_assignment(num)[1])
        correct_num_all = 0
        for l in range(len(self.centroid_tensor_list)):
            xx = np.squeeze(np_label[np_label_pred == l])
            correct_num = np.sum((xx == assignment_index[l]))
            correct_num_all += correct_num
            acu_list.append(round(correct_num / xx.shape[0], 5))

        accuracy = correct_num_all / np_label_pred.shape[0]
        print('  cluster_assignment： ', assignment_index)
        print('highest_frequency：', index_list)
        print('each_cluster_num：', num_list, 'sum：', np_label_pred.shape[0])
        print('cluster_acc：', acu_list)
        print('acc：', accuracy)
        print('_______________________________')
        return accuracy

    def __main__(self):
        list_acu = []
        for i in range(self.iterations):
            if i % 10 == 0 and i != 0 and i >= 40:
                Qc.update_centroid_tensor_list(self)
            print(i)
            Qc.cul_distance(self)
            Qc.distribution_image_to_cluster(self)
            Qc.update_centroid_tensor_list_with_trust_rate(self)
            accuracy = Qc.cul_accuracy_assignment(self)
            if i % 10 == 0:
                list_acu.append(accuracy)
        return list_acu


def feature_map(img_train, img_test, lable_train, lable_test, nor_num, data_type, device):
    theta = 1
    img_train1 = tc.tensor((img_train * np.pi * theta) / nor_num, dtype=data_type, device=device)
    img_test1 = tc.tensor((img_test * np.pi * theta) / nor_num, dtype=data_type, device=device)
    img_train = tc.zeros((img_train.shape[0], img_train.shape[1], 2), dtype=data_type, device=device)
    img_test = tc.zeros((img_test.shape[0], img_test.shape[1], 2), dtype=data_type, device=device)
    img_train[:, :, 0] = tc.cos(img_train1)
    img_train[:, :, 1] = tc.sin(img_train1)
    img_test[:, :, 0] = tc.cos(img_test1)
    img_test[:, :, 1] = tc.sin(img_test1)
    lab_train = tc.squeeze(tc.tensor(lable_train, dtype=tc.long, device=device))
    lab_test = tc.squeeze(tc.tensor(lable_test, dtype=tc.long, device=device))
    return img_train, img_test, lab_train, lab_test


def choose_centorid_list(img_train, lab_train):
    random_number = set(sample(range(img_train.shape[0]), 10))
    all_index = set(range(img_train.shape[0]))
    other_index = list(all_index - random_number)
    centroid_tensor = img_train[list(random_number)]
    centroid_tensor_label = lab_train[list(random_number)]
    train_set = img_train[other_index]
    train_set_label = lab_train[other_index]
    centroid_tensor_list = []
    centroid_tensor_label_list = []
    for i in range(10):
        centroid_tensor_list.append(tc.unsqueeze(centroid_tensor[i, :, :], dim=0))
        centroid_tensor_label_list.append(tc.unsqueeze(centroid_tensor_label[i], dim=0))
    return centroid_tensor_list, centroid_tensor_label_list, train_set, train_set_label


def load_data():
    data_folder = 'mnist/'
    files = [
             'train-labels-idx1-ubyte.gz', 'train-images-idx3-ubyte.gz',
             't10k-labels-idx1-ubyte.gz', 't10k-images-idx3-ubyte.gz'
          ]

    paths = []

    for fname in files:
        paths.append(os.path.join(data_folder, fname))

    with gzip.open(paths[0], 'rb') as lbpath:
        label_train = np.frombuffer(lbpath.read(), np.uint8, offset=8)

    with gzip.open(paths[1], 'rb') as imgpath:
        img_train = np.frombuffer(
            imgpath.read(), np.uint8, offset=16).reshape(len(label_train), -1)

    with gzip.open(paths[2], 'rb') as lbpath:
        label_test = np.frombuffer(lbpath.read(), np.uint8, offset=8)

    with gzip.open(paths[3], 'rb') as imgpath:
        img_test = np.frombuffer(
            imgpath.read(), np.uint8, offset=16).reshape(len(label_test), -1)

    return img_train, label_train, img_test, label_test





