import torch as tc
import numpy as np
from random import sample
import copy
import os
import gzip
from scipy.optimize import linear_sum_assignment


class K_means(object):
    def __init__(self, train_set, train_set_label, centroid_tensor, centroid_tensor_label, data_type, device, batch_num, iterations):
        self.train_set = train_set
        self.data_type = data_type
        self.device = device
        self.batch_num = batch_num
        self.iterations = iterations
        self.train_set_label = train_set_label
        self.centroid_tensor = centroid_tensor
        self.centroid_tensor_label = centroid_tensor_label
        self.label_predict = tc.zeros_like(train_set_label)

    def cul_distance(self):
        total_num = self.train_set.shape[0]
        circle_num = total_num // self.batch_num
        yushu = total_num % self.batch_num
        if total_num % self.batch_num != 0:
            for i in range(circle_num):
                self.label_predict[(i * self.batch_num):(i + 1) * self.batch_num] = \
                    K_means.cul_distance_with_cluster_and_picture_set(self, self.centroid_tensor, self.train_set[(i * self.batch_num):(i + 1) * self.batch_num, :])
            self.label_predict[total_num - yushu:] = \
                K_means.cul_distance_with_cluster_and_picture_set(self, self.centroid_tensor, self.train_set[(total_num - yushu):, :])
        else:
            for i in range(circle_num):
                self.label_predict[(i * self.batch_num):(i + 1) * self.batch_num] = \
                    K_means.cul_distance_with_cluster_and_picture_set(self, self.centroid_tensor, self.train_set[(i * self.batch_num):(i + 1) * self.batch_num, :])

    def cul_distance_with_cluster_and_picture_set(self, centroid_tensor, picture_set):
        b = tc.zeros((centroid_tensor.shape[0], picture_set.shape[0]), dtype=self.data_type, device=self.device)
        for k in range(centroid_tensor.shape[0]):
            tensor_cluster = copy.deepcopy(centroid_tensor[k])
            b[k, :] = tc.norm(picture_set - tensor_cluster, 2, dim=1)
        b = tc.argmin(b, dim=0)
        return b

    def cul_new_centroid(self):
        for i in range(self.centroid_tensor.shape[0]):
            x = self.train_set[self.label_predict == i]
            self.centroid_tensor[i] = tc.sum(x, dim=0)/x.shape[0]

    def distribution_image_0(self):
        K_means.cul_distance(self)
        for k in range(self.centroid_tensor.shape[0]):
            self.train_set = tc.cat((self.train_set, tc.unsqueeze(self.centroid_tensor[k], dim=0)), dim=0)
            a = copy.deepcopy(self.centroid_tensor_label[k])
            self.train_set_label = tc.cat((self.train_set_label, tc.unsqueeze(a, dim=0)), dim=0)
            self.label_predict = tc.cat((self.label_predict, tc.tensor([k], dtype=tc.long, device=self.device)), dim=0)
        K_means.cul_new_centroid(self)

    def cul_accuracy_asianment(self):
        np_label_pred = np.array(self.label_predict.cpu(), dtype=np.long)
        np_label = np.array(self.train_set_label.cpu(), dtype=np.long)
        num = np.zeros((10, 10))
        for i in range(self.centroid_tensor.shape[0]):
            x = np.squeeze(np_label[np_label_pred == i])
            for ii in range(10):
                num[i, ii] = 1 / (np.sum((x == ii)) + 1e-18)

        assignment_index = list(linear_sum_assignment(num)[1])
        correct_num_all = 0
        for l in range(10):
            xx = np.squeeze(np_label[np_label_pred == l])
            correct_num = np.sum((xx == assignment_index[l]))
            correct_num_all += correct_num
        accuracy = correct_num_all / np_label_pred.shape[0]
        return accuracy

    def __main__(self):
        K_means.cul_distance(self)
        K_means.distribution_image_0(self)
        K_means.cul_new_centroid(self)
        accuracy = K_means.cul_accuracy_asianment(self)
        print(accuracy)
        for i in range(self.iterations):
            print(i)
            K_means.cul_distance(self)
            accuracy = K_means.cul_accuracy_asianment(self)
            acu_list.append(accuracy)
            K_means.cul_new_centroid(self)
            print(accuracy)
        return accuracy


def choose_centorid_list(img_train, lab_train):

    random_number = set(sample(range(img_train.shape[0]), 10))
    all_index = set(range(img_train.shape[0]))
    other_index = list(all_index - random_number)
    centroid_tensor = img_train[list(random_number)]
    centroid_tensor_label = lab_train[list(random_number)]
    train_set = img_train[other_index]
    train_set_label = lab_train[other_index]

    return centroid_tensor, centroid_tensor_label, train_set, train_set_label


def make_tensor(train_set, test_set, train_label, test_label, device, data_type):
    train_set = tc.tensor(train_set / 255, device=device, dtype=data_type)
    test_set = tc.tensor(test_set / 255, device=device, dtype=data_type)
    train_label = tc.tensor(train_label, device=device, dtype=tc.long)
    test_label = tc.tensor(test_label, device=device, dtype=tc.long)
    return train_set, test_set, train_label, test_label


def load_data():
    data_folder = 'mnist/'


    files = [
             'train-labels-idx1-ubyte.gz', 'train-images-idx3-ubyte.gz',
             't10k-labels-idx1-ubyte.gz', 't10k-images-idx3-ubyte.gz'
          ]

    paths = []

    for fname in files:
        paths.append(os.path.join(data_folder, fname))

    with gzip.open(paths[0], 'rb') as lbpath:
        label_train = np.frombuffer(lbpath.read(), np.uint8, offset=8)

    with gzip.open(paths[1], 'rb') as imgpath:
        img_train = np.frombuffer(
            imgpath.read(), np.uint8, offset=16).reshape(len(label_train), -1)

    with gzip.open(paths[2], 'rb') as lbpath:
        label_test = np.frombuffer(lbpath.read(), np.uint8, offset=8)

    with gzip.open(paths[3], 'rb') as imgpath:
        img_test = np.frombuffer(
            imgpath.read(), np.uint8, offset=16).reshape(len(label_test), -1)

    return img_train, label_train, img_test, label_test