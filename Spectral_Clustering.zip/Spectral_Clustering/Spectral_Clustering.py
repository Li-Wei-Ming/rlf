import numpy as np
from sklearn import datasets
from sklearn.cluster import SpectralClustering
from sklearn import metrics
import torch as tc
import os
import gzip
from scipy.optimize import linear_sum_assignment


def load_data():
    data_folder = 'mnist/'


    files = [
             'train-labels-idx1-ubyte.gz', 'train-images-idx3-ubyte.gz',
             't10k-labels-idx1-ubyte.gz', 't10k-images-idx3-ubyte.gz'
          ]

    paths = []

    for fname in files:
        paths.append(os.path.join(data_folder, fname))

    with gzip.open(paths[0], 'rb') as lbpath:
        label_train = np.frombuffer(lbpath.read(), np.uint8, offset=8)

    with gzip.open(paths[1], 'rb') as imgpath:
        img_train = np.frombuffer(
            imgpath.read(), np.uint8, offset=16).reshape(len(label_train), -1)

    with gzip.open(paths[2], 'rb') as lbpath:
        label_test = np.frombuffer(lbpath.read(), np.uint8, offset=8)

    with gzip.open(paths[3], 'rb') as imgpath:
        img_test = np.frombuffer(
            imgpath.read(), np.uint8, offset=16).reshape(len(label_test), -1)

    return img_train, label_train, img_test, label_test


def cul_acu_ansiannment(label_predict, train_set_label):
    np_label_pred = np.array(label_predict, dtype=np.long)
    np_label = np.array(train_set_label, dtype=np.long)
    num = np.zeros((10, 10))
    for i in range(10):
        x = np.squeeze(np_label[np_label_pred == i])
        for ii in range(10):
            num[i, ii] = 1 / (np.sum((x == ii)) + 1e-18)

    assignment_index = list(linear_sum_assignment(num)[1])
    correct_num_all = 0
    for l in range(10):
        xx = np.squeeze(np_label[np_label_pred == l])
        correct_num = np.sum((xx == assignment_index[l]))
        correct_num_all += correct_num
    accuracy = correct_num_all / np_label_pred.shape[0]
    return accuracy


img_train, label_train, img_test, label_test = load_data()
img_train, img_test = np.array(img_train, dtype=np.float32)/256,  np.array(img_test, dtype=np.float32)/256

spectral = SpectralClustering()
label_test_predict = np.array(SpectralClustering(n_clusters=10, affinity='nearest_neighbors', n_neighbors=8, assign_labels='kmeans').fit_predict(img_test), dtype=np.int)
acu = cul_acu_ansiannment(label_test_predict, label_test)
print(acu)
