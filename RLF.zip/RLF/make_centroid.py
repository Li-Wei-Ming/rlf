import torch as tc
from random import sample
import numpy as np


class Centroid(object):

    def __init__(self, img_train, lab_train, device):
        self.centroid_tensor, self.centroid_tensor_label, self.train_set, self.train_set_label, self.other_index,  self.select_lable = choose_a_first_centorid(img_train, lab_train)
        self.other_index, self.select_lable = tc.tensor(self.other_index, dtype=tc.long, device=device), tc.tensor(self.select_lable, dtype=tc.long, device=device)
        self.lable_list = []
        self.delete_num = 0
        self.iterations = 1
        self.k = 10
        self.device = device

        self.threshold_value = 1e-15
        self.data_type = tc.float64
        self.batch_num = 2000
        self.base = 1.3

        self.data_type1 = tc.float64
        self.batch_num1 = 2000
        self.base1 = 1.3

    def to_make_centroid(self):
        while self.centroid_tensor.shape[0] < self.k:
            print('sample num:', self.centroid_tensor.shape[0])
            Centroid.add_centroid(self)

    def add_centroid(self):
        distance = Centroid.easy_bulk_cul_with_list0(self)  # class * n
        distance1 = Centroid.easy_bulk_cul_with_list1(self)
        distance_right = (tc.sum((distance < self.threshold_value), dim=0) == distance.shape[0])
        index_range = tc.tensor((range(self.train_set.shape[0])), dtype=tc.long, device=self.device)
        right_index = index_range[distance_right]
        print('satisfaction：', right_index.shape[0])
        distance_topk = tc.sum(distance1[:, distance_right], dim=0)
        min_index = tc.topk(distance_topk, 1, dim=0, largest=False)[1]

        min_index = right_index[min_index]

        b = self.train_set_label[min_index]

        self.centroid_tensor = tc.cat((self.centroid_tensor, self.train_set[min_index, :, :]), dim=0)
        self.centroid_tensor_label = tc.cat((self.centroid_tensor_label, b), dim=0)
        index_all = set(range(self.train_set.shape[0]))
        index_min = []
        index_min.append(min_index.item())
        index_min = set(index_min)
        self.train_set = self.train_set[list(index_all - index_min), :, :]
        self.train_set_label = self.train_set_label[list(index_all - index_min)]
        self.select_lable = tc.cat((self.select_lable, self.other_index[min_index]), dim=0)
        self.other_index = self.other_index[list(index_all - index_min)]

    def cul_trust_rate(self):
        inner_product = Centroid.easy_bulk_cul_with_list(self)[1]
        max_class = tc.zeros(self.centroid_tensor.shape[0], dtype=self.data_type, device=self.device)
        for i in range(self.centroid_tensor.shape[0]):
            max_class[i] = inner_product[i]
        all_tensor = tc.sum(inner_product, dim=0)
        trust_rate = tc.squeeze(max_class / all_tensor)
        return trust_rate, inner_product

    def delete_centroid(self, trust_rate):
        b = tc.topk(trust_rate, self.delete_num, dim=0, largest=False)[1]
        b_list = b.cpu().numpy().tolist()
        delete_index = set(b_list)

        print('delete：', self.centroid_tensor_label[b_list])
        all_index = set(range(trust_rate.shape[0]))

        remain_index = tc.tensor(list(all_index - delete_index), dtype=tc.long, device=self.device)

        self.train_set = tc.cat((self.train_set, self.centroid_tensor[b, :, :]), dim=0)
        self.train_set_label = tc.cat((self.train_set_label, self.centroid_tensor_label[b]), dim=0)
        self.centroid_tensor = self.centroid_tensor[remain_index].type(self.data_type)
        self.centroid_tensor_label = self.centroid_tensor_label[remain_index].type(tc.long)

    def easy_bulk_cul_with_list0(self):
        circle_num = self.train_set.shape[0] // self.batch_num
        yushu = self.train_set.shape[0] % self.batch_num
        if yushu != 0:
            inner_product = tc.zeros((self.centroid_tensor.shape[0], self.train_set.shape[0] - yushu), dtype=self.data_type, device=self.device)
            for i in range(circle_num):
                for ii in range(self.centroid_tensor.shape[0]):
                    inner_product0 = tc.einsum('nld, mld-> nml', [self.train_set[(i * self.batch_num):(i + 1) * self.batch_num, :, :], tc.unsqueeze(self.centroid_tensor[ii], dim=0)])
                    inner_product_1 = tc.log10(inner_product0 + 1e-7)
                    inner_product_1 = tc.einsum('nml-> nm', [inner_product_1])
                    inner_product_1 = self.base ** inner_product_1
                    inner_product[ii:, (i * self.batch_num):(i + 1) * self.batch_num] = tc.einsum('nm-> n', [inner_product_1])
            # 计算剩余部分
            yushu_tensor = tc.zeros((self.centroid_tensor.shape[0], yushu), dtype=self.data_type, device=self.device)
            for iii in range(self.centroid_tensor.shape[0]):
                inner_product00 = tc.einsum('nld, mld-> nml', [self.train_set[(self.train_set.shape[0] - yushu):, :, :], tc.unsqueeze(self.centroid_tensor[iii], dim=0)])
                inner_product_yushu = tc.log10(inner_product00 + 1e-7)
                inner_product_yushu = tc.einsum('nml-> nm', [inner_product_yushu])
                inner_product_yushu = self.base ** inner_product_yushu
                inner_product_yushu = tc.einsum('nm-> n', [inner_product_yushu])
                yushu_tensor[iii, :] = inner_product_yushu
            inner_product = tc.cat((inner_product, yushu_tensor), dim=1)
        else:
            inner_product = tc.zeros((self.centroid_tensor.shape[0], self.train_set.shape[0]), dtype=self.data_type, device=self.device)
            for i in range(circle_num):
                for ii in range(self.centroid_tensor.shape[0]):
                    inner_product0 = tc.einsum('nld, mld-> nml', [self.centroid_tensor[(i * self.batch_num):(i + 1) * self.batch_num, :, :], tc.unsqueeze(self.centroid_tensor[ii], dim=0)])
                    inner_product_yushu = tc.log10(inner_product0 + 1e-7)
                    inner_product_yushu = tc.einsum('nml-> nm', [inner_product_yushu])
                    inner_product_yushu = self.base ** inner_product_yushu
                    inner_product[ii:, (i * self.batch_num):(i + 1) * self.batch_num] = tc.einsum('nm-> n', [inner_product_yushu])
        return inner_product

    def easy_bulk_cul_with_list1(self):
        circle_num = self.train_set.shape[0] // self.batch_num
        yushu = self.train_set.shape[0] % self.batch_num1
        if yushu != 0:
            inner_product = tc.zeros((self.centroid_tensor.shape[0], self.train_set.shape[0] - yushu), dtype=self.data_type1, device=self.device)
            for i in range(circle_num):
                for ii in range(self.centroid_tensor.shape[0]):
                    inner_product0 = tc.einsum('nld, mld-> nml', [self.train_set[(i * self.batch_num1):(i + 1) * self.batch_num1, :, :], tc.unsqueeze(self.centroid_tensor[ii], dim=0)])
                    inner_product_1 = tc.log10(inner_product0 + 1e-7)
                    inner_product_1 = tc.einsum('nml-> nm', [inner_product_1])
                    inner_product_1 = self.base1 ** inner_product_1
                    inner_product[ii:, (i * self.batch_num1):(i + 1) * self.batch_num1] = tc.einsum('nm-> n', [inner_product_1])
            yushu_tensor = tc.zeros((self.centroid_tensor.shape[0], yushu), dtype=self.data_type1, device=self.device)
            for iii in range(self.centroid_tensor.shape[0]):
                inner_product00 = tc.einsum('nld, mld-> nml', [self.train_set[(self.train_set.shape[0] - yushu):, :, :], tc.unsqueeze(self.centroid_tensor[iii], dim=0)])
                inner_product_yushu = tc.log10(inner_product00 + 1e-7)
                inner_product_yushu = tc.einsum('nml-> nm', [inner_product_yushu])
                inner_product_yushu = self.base1 ** inner_product_yushu
                inner_product_yushu = tc.einsum('nm-> n', [inner_product_yushu])
                yushu_tensor[iii, :] = inner_product_yushu
            inner_product = tc.cat((inner_product, yushu_tensor), dim=1)
        else:
            inner_product = tc.zeros((self.centroid_tensor.shape[0], self.train_set.shape[0]), dtype=self.data_type1, device=self.device)
            for i in range(circle_num):
                for ii in range(self.centroid_tensor.shape[0]):
                    inner_product0 = tc.einsum('nld, mld-> nml', [self.centroid_tensor[(i * self.batch_num1):(i + 1) * self.batch_num1, :, :], tc.unsqueeze(self.centroid_tensor[ii], dim=0)])
                    inner_product_yushu = tc.log10(inner_product0 + 1e-7)
                    inner_product_yushu = tc.einsum('nml-> nm', [inner_product_yushu])
                    inner_product_yushu = self.base1 ** inner_product_yushu
                    inner_product[ii:, (i * self.batch_num1):(i + 1) * self.batch_num1] = tc.einsum('nm-> n', [inner_product_yushu])
        return inner_product

    def easy_bulk_cul_with_list(self):
        known_picture_list = []
        ax = self.centroid_tensor
        for zz in range(ax.shape[0]):
            known_picture_list.append(tc.unsqueeze(ax[zz, :, :], dim=0))
        total_num = ax.shape[0]
        circle_num = total_num // self.batch_num
        yushu = total_num % self.batch_num
        if total_num % self.batch_num != 0:
            inner_product = tc.zeros((len(known_picture_list), total_num - yushu), dtype=self.data_type, device=self.device)
            for i in range(circle_num):
                for ii in range(len(known_picture_list)):
                    inner_product0 = tc.einsum('nld, mld-> nml',
                                               [self.centroid_tensor[(i * self.batch_num):(i + 1) * self.batch_num, :, :],
                                                known_picture_list[ii]])
                    inner_product_1 = tc.log10(inner_product0 + 1e-7)
                    inner_product_1 = tc.einsum('nml-> nm', [inner_product_1])
                    inner_product_1 = base2 ** inner_product_1
                    inner_product[ii:, (i * self.batch_num):(i + 1) * self.batch_num] = tc.einsum('nm-> n', [inner_product_1])
            yushu_tensor = tc.zeros((len(known_picture_list), yushu), dtype=self.data_type, device=self.device)
            for iii in range(len(known_picture_list)):
                inner_product00 = tc.einsum('nld, mld-> nml',
                                            [self.centroid_tensor[(total_num - yushu):, :, :], known_picture_list[iii]])
                inner_product_yushu = tc.log10(inner_product00 + 1e-7)
                inner_product_yushu = tc.einsum('nml-> nm', [inner_product_yushu])
                inner_product_yushu = self.base2 ** inner_product_yushu
                inner_product_yushu = tc.einsum('nm-> n', [inner_product_yushu])
                yushu_tensor[iii, :] = inner_product_yushu
            inner_product = tc.cat((inner_product, yushu_tensor), dim=1)

        else:
            inner_product = tc.zeros((len(known_picture_list), total_num), dtype=self.data_type, device=self.device)
            for i in range(circle_num):
                for ii in range(len(known_picture_list)):
                    inner_product0 = tc.einsum('nld, mld-> nml',
                                               [self.centroid_tensor[(i * self.batch_num):(i + 1) * self.batch_num, :, :],
                                                known_picture_list[ii]])
                    inner_product_yushu = tc.log10(inner_product0 + 1e-7)
                    inner_product_yushu = tc.einsum('nml-> nm', [inner_product_yushu])
                    inner_product_yushu = self.base2 ** inner_product_yushu
                    inner_product[ii:, (i * self.batch_num):(i + 1) * self.batch_num] = tc.einsum('nm-> n', [inner_product_yushu])

        return inner_product

    def __main__(self):
        for i in range(self.iterations):
            Centroid.to_make_centroid(self)
            print(i, 'label：', self.centroid_tensor_label)
        print('final', self.centroid_tensor_label)
        return self.centroid_tensor, self.centroid_tensor_label, self.train_set, self.train_set_label,


def choose_a_first_centorid(img_train, lab_train):

    random_number = set(sample(range(img_train.shape[0]), 1))
    all_index = set(range(img_train.shape[0]))
    other_index = list(all_index - random_number)
    centroid_tensor = img_train[list(random_number), :, :]
    centroid_tensor_label = lab_train[list(random_number)]
    train_set = img_train[other_index]
    train_set_label = lab_train[other_index]
    return centroid_tensor, centroid_tensor_label, train_set, train_set_label, other_index, list(random_number)


def to_list(centroid_tensor, centroid_tensor_label):
    centroid_tensor_list = []
    centroid_tensor_label_list = []
    for k in range(centroid_tensor.shape[0]):
        centroid_tensor_list.append(tc.unsqueeze(centroid_tensor[k, :, :], dim=0))
        centroid_tensor_label_list.append(tc.unsqueeze(centroid_tensor_label[k], dim=0))
    return centroid_tensor_list, centroid_tensor_label_list
