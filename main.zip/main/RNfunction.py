import torch as tc
import numpy as np
from random import sample
import os
import gzip


def load_data():
    data_folder = 'mnist/'

    files = [
        'train-labels-idx1-ubyte.gz', 'train-images-idx3-ubyte.gz',
        't10k-labels-idx1-ubyte.gz', 't10k-images-idx3-ubyte.gz'
    ]

    paths = []

    for fname in files:
        paths.append(os.path.join(data_folder, fname))

    with gzip.open(paths[0], 'rb') as lbpath:
        label_train = np.frombuffer(lbpath.read(), np.uint8, offset=8)

    with gzip.open(paths[1], 'rb') as imgpath:
        img_train = np.frombuffer(
            imgpath.read(), np.uint8, offset=16).reshape(len(label_train), -1)

    with gzip.open(paths[2], 'rb') as lbpath:
        label_test = np.frombuffer(lbpath.read(), np.uint8, offset=8)

    with gzip.open(paths[3], 'rb') as imgpath:
        img_test = np.frombuffer(
            imgpath.read(), np.uint8, offset=16).reshape(len(label_test), -1)

    return img_train, label_train, img_test, label_test


class Semi(object):
    def __init__(self, img, label, choose_num_first, add_num, data_type_list, base_list, device, circle_num, batch_num, delete_para_list, delete_mode, update_para_list,  img_test, label_test):

        # 更新聚类中心参数 ————————————————————————————————————————

        self.update_freq, self.update_times = update_para_list[0], update_para_list[1]
        self.delete_mode = delete_mode
        self.delete_num, self.delete_rate = delete_para_list[0], delete_para_list[1]
        self.delete_num_list = []

        # 添加聚类中心参数 ————————————————————————————————————————
        self.circle_num = circle_num
        self.choose_num_first = choose_num_first
        self.add_num = add_num
        self.batch_num = batch_num
        self.nor_num = 255
        self.k = 10
        self.device = device

        # 计算参数 ————————————————————————————————————————
        self.data_type_cul = data_type_list[0]
        self.data_type_cul_trust = data_type_list[1]
        self.data_type_inner_product = data_type_list[2]
        self.base_cul = base_list[0]
        self.base_trust = base_list[1]

        #  图像数据 ————————————————————————
        self.center_given, self.unlabel_pictures, self.unlabel_pictures_ture_label = Semi.feature_map_and_to_allo(self, img, label)
        self.unlabel_pictures_label_predict = tc.zeros(self.unlabel_pictures.shape[0], dtype=tc.long, device=self.device)
        self.center_predict = []
        self.center_predict_label_ture = []

        self.img_test, self.label_test = Semi.feature_map_test(self, img_test, label_test)

    def feature_map_test(self, img_test, label_test):
        img_test = (img_test / self.nor_num)
        img0 = tc.tensor(img_test * np.pi/2, dtype=self.data_type_cul, device=self.device)
        img_test = tc.zeros((img_test.shape[0], img_test.shape[1], 2), dtype=self.data_type_cul, device=self.device)

        img_test[:, :, 0] = tc.cos(img0)
        img_test[:, :, 1] = tc.sin(img0)

        label_test = tc.squeeze(tc.tensor(label_test, dtype=tc.long, device=self.device))
        return img_test, label_test

    def cul_label(self):
        batch_num = self.batch_num
        total_num = self.unlabel_pictures.shape[0]
        circle_num = total_num // batch_num
        yushu = total_num % batch_num
        if yushu != 0:
            inner_product = tc.zeros((len(self.center_given), total_num - yushu), dtype=self.data_type_inner_product, device=self.device)
            for i in range(circle_num):
                for ii in range(len(self.center_given)):
                    inner_product0 = tc.einsum('nld, mld-> nml', [self.unlabel_pictures[(i * batch_num):(i + 1) * batch_num, :, :], tc.cat((self.center_given[ii],  self.center_predict[ii]), dim=0)])
                    inner_product[ii:, (i * batch_num):(i + 1) * batch_num] = tc.einsum('nm-> n', [self.base_cul ** tc.einsum('nml-> nm', [tc.log10(inner_product0 + 1e-7)])])/(self.center_given[ii].shape[0] + self.center_predict[ii].shape[0])
            yushu_tensor = tc.zeros((len(self.center_given), yushu), dtype=self.data_type_inner_product, device=self.device)
            for iii in range(len(self.center_given)):
                inner_product00 = tc.einsum('nld, mld-> nml', [self.unlabel_pictures[(total_num - yushu):, :, :], tc.cat((self.center_given[iii],  self.center_predict[iii]), dim=0)])
                inner_product_yushu = tc.einsum('nm-> n', [self.base_cul ** tc.einsum('nml-> nm', [tc.log10(inner_product00 + 1e-7)])])/(self.center_given[iii].shape[0] + self.center_predict[iii].shape[0])
                yushu_tensor[iii, :] = inner_product_yushu
            inner_product = tc.cat((inner_product, yushu_tensor), dim=1)
        else:
            inner_product = tc.zeros((len(self.center_given), total_num), dtype=self.data_type_inner_product, device=self.device)
            for i in range(circle_num):
                for ii in range(len(self.center_given)):
                    inner_product0 = tc.einsum('nld, mld-> nml', [self.unlabel_pictures[(i * batch_num):(i + 1) * batch_num, :, :], tc.cat((self.center_given[ii],  self.center_predict[ii]), dim=0)])
                    inner_product[ii:, (i * batch_num):(i + 1) * batch_num] = tc.einsum('nm-> n', [self.base_cul ** tc.einsum('nml-> nm', [tc.log10(inner_product0 + 1e-7)])])/(self.center_given[ii].shape[0] + self.center_predict[ii].shape[0])
        return inner_product

    def cul_label_first(self):
        each_num = self.center_given[0].shape[0]
        batch_num = self.batch_num
        total_num = self.unlabel_pictures.shape[0]
        circle_num = total_num // batch_num
        yushu = total_num % batch_num
        if yushu != 0:
            inner_product = tc.zeros((len(self.center_given), total_num - yushu), dtype=self.data_type_inner_product, device=self.device)
            for i in range(circle_num):
                for ii in range(len(self.center_given)):

                    inner_product0 = tc.einsum('nld, mld-> nml', [self.unlabel_pictures[(i * batch_num):(i + 1) * batch_num, :, :], self.center_given[ii]])
                    inner_product[ii:, (i * batch_num):(i + 1) * batch_num] = tc.einsum('nm-> n', [self.base_cul ** tc.einsum('nml-> nm', [tc.log10(inner_product0 + 1e-7)])])/each_num
            yushu_tensor = tc.zeros((len(self.center_given), yushu), dtype=self.data_type_inner_product, device=self.device)
            for iii in range(len(self.center_given)):

                inner_product00 = tc.einsum('nld, mld-> nml', [self.unlabel_pictures[(total_num - yushu):, :, :], self.center_given[iii]])
                inner_product_yushu = tc.einsum('nm-> n', [self.base_cul ** tc.einsum('nml-> nm', [tc.log10(inner_product00 + 1e-7)])])/each_num
                yushu_tensor[iii, :] = inner_product_yushu
            inner_product = tc.cat((inner_product, yushu_tensor), dim=1)
        else:
            inner_product = tc.zeros((len(self.center_given), total_num), dtype=self.data_type_inner_product, device=self.device)
            for i in range(circle_num):
                for ii in range(len(self.center_given)):

                    inner_product0 = tc.einsum('nld, mld-> nml', [self.unlabel_pictures[(i * batch_num):(i + 1) * batch_num, :, :], self.center_given[ii]])
                    inner_product[ii:, (i * batch_num):(i + 1) * batch_num] = tc.einsum('nm-> n', [self.base_cul ** tc.einsum('nml-> nm', [tc.log10(inner_product0 + 1e-7)])])/each_num
        return inner_product

    def add_pictures_to_center_predict(self, circle, add_mode):
        if add_mode == 'add':
            add_num = self.add_num
        elif add_mode == 'add_delete':
            add_num = self.delete_num_list[0]
        if circle != 0:
            each_value, each_class = tc.topk(Semi.cul_label(self), 1, dim=0, largest=True)
        elif circle == 0:
            each_value, each_class = tc.topk(Semi.cul_label_first(self), 1, dim=0, largest=True)
        each_value, each_class = tc.squeeze(each_value), tc.squeeze(each_class)
        index_tensor = tc.tensor(range(each_class.shape[0]), device=self.device, dtype=tc.long)

        if circle != 0:
            select_index_list = []
            for i in range(len(self.center_given)):
                index = index_tensor[each_class == i]
                if index.shape[0] < self.add_num:
                    self.center_predict[i] = tc.cat((self.center_predict[i], self.unlabel_pictures[index]), dim=0)
                    self.center_predict_label_ture[i] = tc.cat((self.center_predict_label_ture[i], self.unlabel_pictures_ture_label[index]), dim=0)

                    select_index_list += index.cpu().numpy().tolist()
                else:
                    best_index = tc.topk(each_value[index], add_num, dim=0, largest=True)[1]
                    index_best = index[best_index]

                    select_index_list += index_best.cpu().numpy().tolist()

                    self.center_predict[i] = tc.cat((self.center_predict[i], self.unlabel_pictures[index_best]), dim=0)
                    self.center_predict_label_ture[i] = tc.cat((self.center_predict_label_ture[i], self.unlabel_pictures_ture_label[index_best]), dim=0)

            unlabel_index_list = list(set(range(each_class.shape[0])) - set(select_index_list))
            self.unlabel_pictures = self.unlabel_pictures[unlabel_index_list]
            self.unlabel_pictures_ture_label = self.unlabel_pictures_ture_label[unlabel_index_list]
            self.unlabel_pictures_label_predict = each_class[unlabel_index_list]

        elif circle == 0:
            select_index_list = []
            for i in range(len(self.center_given)):
                index = index_tensor[each_class == i]
                if index.shape[0] < add_num:
                    self.center_predict.append(self.unlabel_pictures[index])
                    self.center_predict_label_ture.append(self.unlabel_pictures_ture_label[index])
                    select_index_list += index.cpu().numpy().tolist()

                else:
                    best_index = tc.topk(each_value[index], add_num, dim=0, largest=True)[1]
                    index_best = index[best_index]

                    select_index_list += index_best.cpu().numpy().tolist()

                    self.center_predict.append(self.unlabel_pictures[index_best])
                    self.center_predict_label_ture.append(self.unlabel_pictures_ture_label[index_best])

            unlabel_index_list = list(set(range(each_class.shape[0])) - set(select_index_list))
            self.unlabel_pictures = self.unlabel_pictures[unlabel_index_list]
            self.unlabel_pictures_ture_label = self.unlabel_pictures_ture_label[unlabel_index_list]
            self.unlabel_pictures_label_predict = each_class[unlabel_index_list]

    def cul_inner_product_self(self, class_num):
        total_num = self.center_predict[class_num].shape[0]
        batch_num = self.batch_num
        circle_num = total_num // batch_num
        yushu = total_num % batch_num
        if yushu != 0:
            inner_product = tc.zeros((len(self.center_given), total_num - yushu), dtype=self.data_type_cul_trust, device=self.device)
            for i in range(circle_num):
                for ii in range(len(self.center_given)):
                    base = self.base_trust
                    inner_product0 = tc.einsum('nld, mld-> nml', [(self.center_predict[class_num])[(i * batch_num):(i + 1) * batch_num, :, :], tc.cat((self.center_given[ii],  self.center_predict[ii]), dim=0)])
                    inner_product[ii:, (i * batch_num):(i + 1) * batch_num] = tc.einsum('nm-> n', [base ** tc.einsum('nml-> nm', [tc.log10(inner_product0 + 1e-7)])])
            yushu_tensor = tc.zeros((len(self.center_given), yushu), dtype=self.data_type_cul_trust, device=self.device)
            for iii in range(len(self.center_given)):
                base = self.base_trust
                inner_product00 = tc.einsum('nld, mld-> nml', [(self.center_predict[class_num])[(total_num - yushu):, :, :], tc.cat((self.center_given[iii],  self.center_predict[iii]), dim=0)])
                inner_product_yushu = tc.einsum('nm-> n', [base ** tc.einsum('nml-> nm', [tc.log10(inner_product00 + 1e-7)])])
                yushu_tensor[iii, :] = inner_product_yushu
            inner_product = tc.cat((inner_product, yushu_tensor), dim=1)
        else:
            inner_product = tc.zeros((len(self.center_given), total_num), dtype=self.data_type_cul_trust, device=self.device)
            for i in range(circle_num):
                for ii in range(len(self.center_given)):
                    base = self.base_trust
                    inner_product0 = tc.einsum('nld, mld-> nml', [(self.center_predict[class_num])[(i * batch_num):(i + 1) * batch_num, :, :], tc.cat((self.center_given[ii],  self.center_predict[ii]), dim=0)])
                    inner_product[ii:, (i * batch_num):(i + 1) * batch_num] = tc.einsum('nm-> n', [base ** tc.einsum('nml-> nm', [tc.log10(inner_product0 + 1e-7)])])
        return inner_product

    def cul_inner_product_self_given(self, class_num):
        batch_num = self.batch_num
        circle_num = total_num // batch_num
        yushu = total_num % batch_num
        if yushu != 0:
            inner_product = tc.zeros((len(self.center_given), total_num - yushu), dtype=self.data_type_cul_trust, device=self.device)
            for i in range(circle_num):
                for ii in range(len(self.center_given)):
                    inner_product0 = tc.einsum('nld, mld-> nml', [(self.center_given[class_num])[(i * batch_num):(i + 1) * batch_num, :, :], self.center_given[ii]])
                    inner_product[ii:, (i * batch_num):(i + 1) * batch_num] = tc.einsum('nm-> n', [Semi.cul_base(self, ii) ** tc.einsum('nml-> nm', [tc.log10(inner_product0 + 1e-7)])])
            yushu_tensor = tc.zeros((len(self.center_given), yushu), dtype=self.data_type_cul_trust, device=self.device)
            for iii in range(len(self.center_given)):
                inner_product00 = tc.einsum('nld, mld-> nml', [(self.center_given[class_num])[(total_num - yushu):, :, :], self.center_given[iii]])
                inner_product_yushu = tc.einsum('nm-> n', [Semi.cul_base(self, iii) ** tc.einsum('nml-> nm', [tc.log10(inner_product00 + 1e-7)])])
                yushu_tensor[iii, :] = inner_product_yushu
            inner_product = tc.cat((inner_product, yushu_tensor), dim=1)
        else:
            inner_product = tc.zeros((len(self.center_given), total_num), dtype=self.data_type_cul_trust, device=self.device)
            for i in range(circle_num):
                for ii in range(len(self.center_given)):
                    inner_product0 = tc.einsum('nld, mld-> nml', [(self.center_given[class_num])[(i * batch_num):(i + 1) * batch_num, :, :], self.center_given[ii]])
                    inner_product[ii:, (i * batch_num):(i + 1) * batch_num] = tc.einsum('nm-> n', [Semi.cul_base(self, ii) ** tc.einsum('nml-> nm', [tc.log10(inner_product0 + 1e-7)])])
        return inner_product

    def update_centroid_tensor_list_with_trust_rate(self):
        trust_rate_list = []
        for k in range(len(self.center_given)):
            inner_product = Semi.cul_inner_product_self(self, k)
            for i in range(len(self.center_given)):
                if i == k:
                    inner_product[i, :] = (inner_product[i, :] - 1) / (self.center_given[i].shape[0] + self.center_predict[i].shape[0] - 1)
                else:
                    inner_product[i, :] = inner_product[i, :] / (self.center_given[i].shape[0] + self.center_predict[i].shape[0])
            trust_rate = inner_product[k, :] / tc.sum(inner_product, dim=0)
            trust_rate_list.append(trust_rate)

        delete_num_list = []

        for k in range(len(self.center_given)):
            trust_rate0 = trust_rate_list[k]
            if trust_rate0.shape[0] <= self.delete_num:
                trust_num = trust_rate0.shape[0]
            if self.delete_mode == 0:
                trust_num = int(trust_rate0.shape[0]*(1 - self.delete_rate))
            elif self.delete_mode == 1:
                trust_num = trust_rate0.shape[0] - self.delete_num

            delete_num_list.append(trust_rate0.shape[0] - trust_num)
            remain_index = tc.topk(trust_rate0, trust_num, dim=0, largest=True)[1]
            delete_index = tc.topk(trust_rate0, trust_rate0.shape[0] - trust_num, dim=0, largest=False)[1]

            self.unlabel_pictures = tc.cat((self.unlabel_pictures, (self.center_predict[k])[delete_index]), dim=0)
            self.unlabel_pictures_ture_label = tc.cat((self.unlabel_pictures_ture_label, (self.center_predict_label_ture[k])[delete_index]), dim=0)
            self.center_predict[k] = (self.center_predict[k])[remain_index]
            self.center_predict_label_ture[k] = (self.center_predict_label_ture[k])[remain_index]
        return delete_num_list

    def feature_map_and_to_allo(self, img, label):
        center_given = []
        img = (img / self.nor_num)
        img0 = tc.tensor(img * np.pi/2 , dtype=self.data_type_cul, device=self.device)
        img = tc.zeros((img0.shape[0], img0.shape[1], 2), dtype=self.data_type_cul, device=self.device)

        img[:, :, 0] = tc.cos(img0)
        img[:, :, 1] = tc.sin(img0)

        lab = tc.squeeze(tc.tensor(label, dtype=tc.long, device=self.device))

        other_picture_index_list = []

        for i in range(self.k):
            a = (tc.squeeze((lab == i).nonzero(), dim=1)).type(tc.long)
            random_number = set(sample(range(a.shape[0]), self.choose_num_first))
            random_number_list = list(random_number)

            means_vectors_index = a[random_number_list]
            list_all_picture = set(range(a.shape[0]))

            other_picture_index = list(list_all_picture - random_number)

            center_given.append(img[means_vectors_index])
            other_picture_index_list = other_picture_index_list + other_picture_index

        unlabel_pictures = img[other_picture_index_list]
        unlabel_pictures_ture_label = lab[other_picture_index_list]
        return center_given, unlabel_pictures, unlabel_pictures_ture_label

    def cul_accuracy(self):
        acu_list = []
        num_list = []
        label_pred = self.unlabel_pictures_label_predict
        label = self.unlabel_pictures_ture_label
        lable_pred_num = 0
        for x in range(len(self.center_given)):
            lable_pred_num += self.center_predict[x].shape[0]
            label_pred = tc.cat((label_pred, tc.full([self.center_predict[x].shape[0]], x, device=self.device, dtype=tc.long)), dim=0)
            label = tc.cat((label, self.center_predict_label_ture[x]), dim=0)

        acu_pre = tc.sum(label_pred[self.unlabel_pictures_label_predict.shape[0]:] == label[self.unlabel_pictures_label_predict.shape[0]:], dim=0).item()/lable_pred_num

        for i in range(len(self.center_given)):
            ture_num = tc.squeeze(label[label_pred == i]) == i
            num_list.append(ture_num.shape[0])
            acu_list.append(round(tc.sum(ture_num, dim=0).item()/ture_num.shape[0], 5))

        accuracy = round(tc.sum(label_pred == label, dim=0).item()/label.shape[0], 5)
        print('each_class_num：', self.center_predict[0].shape[0]*self.k)
        print('each_class_acc', acu_list)
        return accuracy, acu_pre

    def cul_test_acu(self):
        batch_num = self.batch_num
        total_num = self.img_test.shape[0]
        circle_num = total_num // batch_num
        yushu = total_num % batch_num
        if yushu != 0:
            inner_product = tc.zeros((len(self.center_given), total_num - yushu), dtype=self.data_type_inner_product,device=self.device)
            for i in range(circle_num):
                for ii in range(len(self.center_given)):
                    inner_product0 = tc.einsum('nld, mld-> nml', [self.img_test[(i * batch_num):(i + 1) * batch_num, :, :], tc.cat((self.center_given[ii], self.center_predict[ii]), dim=0)])
                    inner_product[ii:, (i * batch_num):(i + 1) * batch_num] = tc.einsum('nm-> n', [self.base_cul ** tc.einsum('nml-> nm', [tc.log10(inner_product0 + 1e-7)])]) / (self.center_given[ii].shape[0] +self.center_predict[ii].shape[0])
            yushu_tensor = tc.zeros((len(self.center_given), yushu), dtype=self.data_type_inner_product, device=self.device)
            for iii in range(len(self.center_given)):
                inner_product00 = tc.einsum('nld, mld-> nml', [self.img_test[(total_num - yushu):, :, :], tc.cat((self.center_given[iii], self.center_predict[iii]), dim=0)])
                inner_product_yushu = tc.einsum('nm-> n', [self.base_cul ** tc.einsum('nml-> nm', [tc.log10(inner_product00 + 1e-7)])]) / (self.center_given[iii].shape[0] + self.center_predict[iii].shape[0])
                yushu_tensor[iii, :] = inner_product_yushu
            inner_product = tc.cat((inner_product, yushu_tensor), dim=1)
        else:
            inner_product = tc.zeros((len(self.center_given), total_num), dtype=self.data_type_inner_product,device=self.device)
            for i in range(circle_num):
                for ii in range(len(self.center_given)):
                    inner_product0 = tc.einsum('nld, mld-> nml', [self.img_test[(i * batch_num):(i + 1) * batch_num, :, :], tc.cat((self.center_given[ii], self.center_predict[ii]), dim=0)])
                    inner_product[ii:, (i * batch_num):(i + 1) * batch_num] = tc.einsum('nm-> n', [self.base_cul ** tc.einsum('nml-> nm', [tc.log10(inner_product0 + 1e-7)])]) / (self.center_given[ii].shape[0] +self.center_predict[ii].shape[0])
        test_label_predict = tc.argmax(inner_product, dim=0)
        acu_test = round(tc.sum((test_label_predict == self.label_test), dim=0).item()/self.label_test.shape[0], 5)
        return acu_test

    def cul_test_acu_first(self):
        batch_num = self.batch_num
        total_num = self.img_test.shape[0]
        circle_num = total_num // batch_num
        yushu = total_num % batch_num
        if yushu != 0:
            inner_product = tc.zeros((len(self.center_given), total_num - yushu), dtype=self.data_type_inner_product, device=self.device)
            for i in range(circle_num):
                for ii in range(len(self.center_given)):
                    inner_product0 = tc.einsum('nld, mld-> nml', [self.img_test[(i * batch_num):(i + 1) * batch_num, :, :], self.center_given[ii]])
                    inner_product[ii:, (i * batch_num):(i + 1) * batch_num] = tc.einsum('nm-> n', [self.base_cul ** tc.einsum('nml-> nm', [tc.log10(inner_product0 + 1e-7)])]) / self.center_given[ii].shape[0]

            yushu_tensor = tc.zeros((len(self.center_given), yushu), dtype=self.data_type_inner_product, device=self.device)
            for iii in range(len(self.center_given)):
                inner_product00 = tc.einsum('nld, mld-> nml', [self.img_test[(total_num - yushu):, :, :], self.center_given[iii]])
                inner_product_yushu = tc.einsum('nm-> n', [self.base_cul ** tc.einsum('nml-> nm', [tc.log10(inner_product00 + 1e-7)])]) / self.center_given[iii].shape[0]
                yushu_tensor[iii, :] = inner_product_yushu
            inner_product = tc.cat((inner_product, yushu_tensor), dim=1)
        else:
            inner_product = tc.zeros((len(self.center_given), total_num), dtype=self.data_type_inner_product,device=self.device)
            for i in range(circle_num):
                for ii in range(len(self.center_given)):
                    inner_product0 = tc.einsum('nld, mld-> nml', [self.img_test[(i * batch_num):(i + 1) * batch_num, :, :], self.center_given[ii]])
                    inner_product[ii:, (i * batch_num):(i + 1) * batch_num] = tc.einsum('nm-> n', [self.base_cul ** tc.einsum('nml-> nm', [tc.log10(inner_product0 + 1e-7)])]) / self.center_given[ii].shape[0]
        test_label_predict = tc.argmax(inner_product, dim=0)
        acu_test = round(tc.sum((test_label_predict == self.label_test), dim=0).item()/self.label_test.shape[0], 5)
        return acu_test

    def __main__(self):
        print('initial_labeled_sample_num：', self.center_given[0].shape[0])
        test_acc_f = Semi.cul_test_acu_first(self)
        print('acc_test_initial：', test_acc_f)
        print('_______________________________')
        for i in range(self.circle_num):
            print(i)
            Semi.add_pictures_to_center_predict(self, i, 'add')
            accuracy, acu_pre = Semi.cul_accuracy(self)
            acu_test = Semi.cul_test_acu(self)
            print('train_acc:', accuracy, 'p_acc:', acu_pre, 'acu_test:', acu_test)
            print('_______________________________')
            if self.update_freq == 0:
                for ii in range(self.update_times):
                    print('update:', i, '-', ii)
                    self.delete_num_list = Semi.update_centroid_tensor_list_with_trust_rate(self)
                    Semi.add_pictures_to_center_predict(self, 1, 'add_delete')
            elif i % self.update_freq == 0 and i != 0:
                for ii in range(self.update_times):
                    print('update:', i, '-', ii)
                    self.delete_num_list = Semi.update_centroid_tensor_list_with_trust_rate(self)
                    Semi.add_pictures_to_center_predict(self, 1, 'add_delete')


