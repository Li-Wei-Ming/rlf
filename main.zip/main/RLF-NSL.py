import numpy as np
import torch as tc
import os
import gzip


def load_data():
    data_folder = 'mnist/'
    files = [
             'train-labels-idx1-ubyte.gz', 'train-images-idx3-ubyte.gz',
             't10k-labels-idx1-ubyte.gz', 't10k-images-idx3-ubyte.gz'
          ]

    paths = []

    for fname in files:
        paths.append(os.path.join(data_folder, fname))

    with gzip.open(paths[0], 'rb') as lbpath:
        label_train = np.frombuffer(lbpath.read(), np.uint8, offset=8)

    with gzip.open(paths[1], 'rb') as imgpath:
        img_train = np.frombuffer(
            imgpath.read(), np.uint8, offset=16).reshape(len(label_train), -1)

    with gzip.open(paths[2], 'rb') as lbpath:
        label_test = np.frombuffer(lbpath.read(), np.uint8, offset=8)

    with gzip.open(paths[3], 'rb') as imgpath:
        img_test = np.frombuffer(
            imgpath.read(), np.uint8, offset=16).reshape(len(label_test), -1)
    return img_train, label_train, img_test, label_test


def feature_map(device, data_type):
    img_train, label_train, img_test, label_test = load_data()
    label_train = tc.tensor(label_train, dtype=tc.long, device = device)
    label_test = tc.tensor(label_test, dtype=tc.long, device = device)
    img_train1 = tc.zeros((img_train.shape[0], img_train.shape[1], 2), dtype=tc.float32, device=device)
    img_train1[:, :, 0] = tc.sin(tc.tensor(img_train, dtype=data_type, device=device) * np.pi/(255*2))
    img_train1[:, :, 1] = tc.cos(tc.tensor(img_train, dtype=data_type, device=device) * np.pi/(255*2))
    img_test1 = tc.zeros((img_test.shape[0], img_test.shape[1], 2), dtype=tc.float32, device=device)
    img_test1[:, :, 0] = tc.sin(tc.tensor(img_test, dtype=data_type, device=device) * np.pi/(255*2))
    img_test1[:, :, 1] = tc.cos(tc.tensor(img_test, dtype=data_type, device=device) * np.pi/(255*2))
    center_given = []
    center_given_label = []
    for i in range(10):
        center_given.append(img_train1[label_train == i, :, :])
        center_given_label.append(label_train[label_train == i])
    return center_given, center_given_label, img_test1, label_test


def cul_label(batch_num, unlabel_pictures, center_given, device, data_type, base, test_set_label):
    total_num = unlabel_pictures.shape[0]
    circle_num = total_num // batch_num
    yushu = total_num % batch_num
    if yushu != 0:
        inner_product = tc.zeros((len(center_given), total_num - yushu), dtype=data_type, device=device)
        for i in range(circle_num):
            for ii in range(len(center_given)):
                inner_product0 = tc.einsum('nld, mld-> nml', [unlabel_pictures[(i * batch_num):(i + 1) * batch_num, :, :], center_given[ii]])
                inner_product[ii:, (i * batch_num):(i + 1) * batch_num] = tc.einsum('nm-> n', [base ** tc.einsum('nml-> nm', [tc.log10(inner_product0 + 1e-7)])])/center_given[ii].shape[0]
        yushu_tensor = tc.zeros((len(center_given), yushu), dtype=data_type, device=device)
        for iii in range(len(center_given)):
            inner_product00 = tc.einsum('nld, mld-> nml', [unlabel_pictures[(total_num - yushu):, :, :], center_given[iii]])
            inner_product_yushu = tc.einsum('nm-> n', [base ** tc.einsum('nml-> nm', [tc.log10(inner_product00 + 1e-7)])])/center_given[iii].shape[0]
            yushu_tensor[iii, :] = inner_product_yushu
        inner_product = tc.cat((inner_product, yushu_tensor), dim=1)
    else:
        inner_product = tc.zeros((len(self.center_given), total_num), dtype=data_type_inner_product, device=device)
        for i in range(circle_num):
            for ii in range(len(center_given)):
                inner_product0 = tc.einsum('nld, mld-> nml', [unlabel_pictures[(i * batch_num):(i + 1) * batch_num, :, :], center_given[ii]])
                inner_product[ii:, (i * batch_num):(i + 1) * batch_num] = tc.einsum('nm-> n', [base ** tc.einsum('nml-> nm', [tc.log10(inner_product0 + 1e-7)])])/center_given[ii].shape[0]
    lable_predict = tc.argmax(inner_product, dim=0)
    test_acc = tc.sum(test_set_label == lable_predict, dim=0).item() / test_set_label.shape[0]
    return test_acc


def cul_test_acc(batch_num, known_picture_list, unknown_picture, label_test, base):
    total_num = unknown_picture.shape[0]
    circle_num = total_num // batch_num
    yushu = total_num % batch_num
    if total_num % batch_num != 0:
        inner_product = tc.zeros((len(known_picture_list), total_num - yushu), dtype=tc.float64, device='cuda:0')
        for i in range(circle_num):
            for ii in range(len(known_picture_list)):
                inner_product0 = tc.einsum('nld, mld-> nml', [unknown_picture[(i * batch_num):(i + 1) * batch_num, :, :], known_picture_list[ii]])
                inner_product_1 = tc.log10(inner_product0 + 1e-7)
                inner_product_1 = tc.einsum('nml-> nm', [inner_product_1])
                inner_product_1 = base ** inner_product_1
                inner_product[ii:, (i * batch_num):(i + 1) * batch_num] = tc.einsum('nm-> n', [inner_product_1])/ known_picture_list[ii].shape[0]

        yushu_tensor = tc.zeros((len(known_picture_list), yushu), dtype=tc.float64, device='cuda:0')
        for iii in range(len(known_picture_list)):
            inner_product00 = tc.einsum('nld, mld-> nml', [unknown_picture[(total_num - yushu):, :, :], known_picture_list[iii]])
            inner_product_yushu = tc.log10(inner_product00 + 1e-7)
            inner_product_yushu = tc.einsum('nml-> nm', [inner_product_yushu])
            inner_product_yushu = base ** inner_product_yushu
            inner_product_yushu = tc.einsum('nm-> n', [inner_product_yushu])/ known_picture_list[iii].shape[0]
            yushu_tensor[iii, :] = inner_product_yushu
        inner_product = tc.cat((inner_product, yushu_tensor), dim=1)

    else:
        inner_product = tc.zeros((len(known_picture_list), total_num), dtype=tc.float64, device='cuda:0')
        for i in range(circle_num):
            for ii in range(len(known_picture_list)):
                inner_product0 = tc.einsum('nld, mld-> nml', [unknown_picture[(i * batch_num):(i + 1) * batch_num, :, :], known_picture_list[ii]])
                inner_product_yushu = tc.log10(inner_product0 + 1e-7)
                inner_product_yushu = tc.einsum('nml-> nm', [inner_product_yushu])
                inner_product_yushu = base ** inner_product_yushu
                inner_product[ii:, (i * batch_num):(i + 1) * batch_num] = tc.einsum('nm-> n', [inner_product_yushu]) / known_picture_list[ii].shape[0]
    lable_predict = tc.argmax(inner_product, dim=0)
    test_acc = tc.sum(label_test == lable_predict, dim=0).item() / label_test.shape[0]
    return test_acc


base = 1.3
batch_num = 60
device = 'cuda:0'
data_type = tc.float32
train_set, train_set_label, test_set, test_set_label = feature_map(device, data_type)
test_acc = cul_label(batch_num, test_set, train_set, device, data_type, base, test_set_label)
# test_acc = cul_test_acc(batch_num, train_set, test_set, test_set_label, base)
print('test_acc:', test_acc)

