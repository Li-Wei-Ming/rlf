import numpy as np
import torch as tc
import os
import gzip
from sklearn import svm
from random import sample
from sklearn.neighbors import KNeighborsClassifier


def load_data():
    data_folder = 'mnist/'


    files = [
             'train-labels-idx1-ubyte.gz', 'train-images-idx3-ubyte.gz',
             't10k-labels-idx1-ubyte.gz', 't10k-images-idx3-ubyte.gz'
          ]

    paths = []

    for fname in files:
        paths.append(os.path.join(data_folder, fname))

    with gzip.open(paths[0], 'rb') as lbpath:
        label_train = np.frombuffer(lbpath.read(), np.uint8, offset=8)

    with gzip.open(paths[1], 'rb') as imgpath:
        img_train = np.frombuffer(
            imgpath.read(), np.uint8, offset=16).reshape(len(label_train), -1)

    with gzip.open(paths[2], 'rb') as lbpath:
        label_test = np.frombuffer(lbpath.read(), np.uint8, offset=8)

    with gzip.open(paths[3], 'rb') as imgpath:
        img_test = np.frombuffer(
            imgpath.read(), np.uint8, offset=16).reshape(len(label_test), -1)

    return img_train, label_train, img_test, label_test


def select_data(lab, img, num):
    center_given = np.zeros((1, 784))
    center_given_label = np.zeros((1))
    for i in range(10):
        a = img[lab == i, :]
        random_number = list(sample(range(a.shape[0]), num))
        center_given = np.concatenate((center_given, a[random_number]), axis=0)
        center_given_label = np.concatenate((center_given_label, np.full(num, i)), axis=0)
    return center_given[1:, :], center_given_label[1:]


train_sample_num = 6

img_train, label_train, img_test, label_test = load_data()
img_train, img_test = img_train/255, img_test/255
img_train, label_train = select_data(label_train, img_train, train_sample_num)

neigh = KNeighborsClassifier(n_neighbors=1)
neigh.fit(img_train, label_train)
test_acc = np.sum(neigh.predict(img_test) == label_test)/label_test.shape[0]
print(test_acc)

