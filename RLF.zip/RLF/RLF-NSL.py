import numpy as np
import torch as tc
import os
import gzip
from random import sample

def load_data():
    data_folder = 'mnist/'


    files = [
             'train-labels-idx1-ubyte.gz', 'train-images-idx3-ubyte.gz',
             't10k-labels-idx1-ubyte.gz', 't10k-images-idx3-ubyte.gz'
          ]

    paths = []

    for fname in files:
        paths.append(os.path.join(data_folder, fname))

    with gzip.open(paths[0], 'rb') as lbpath:
        label_train = np.frombuffer(lbpath.read(), np.uint8, offset=8)

    with gzip.open(paths[1], 'rb') as imgpath:
        img_train = np.frombuffer(
            imgpath.read(), np.uint8, offset=16).reshape(len(label_train), -1)

    with gzip.open(paths[2], 'rb') as lbpath:
        label_test = np.frombuffer(lbpath.read(), np.uint8, offset=8)

    with gzip.open(paths[3], 'rb') as imgpath:
        img_test = np.frombuffer(
            imgpath.read(), np.uint8, offset=16).reshape(len(label_test), -1)

    return img_train, label_train, img_test, label_test


def feature_map(img_train, img_test, label_train, label_test, nor_num, data_type, device):
    theta = 1
    img_train1 = (tc.tensor((img_train * np.pi * theta) / nor_num)).to(device)
    img_test1 = (tc.tensor((img_test * np.pi * theta) / nor_num)).to(device)
    img_train = tc.zeros((60000, 784, 2), dtype=data_type, device=device)
    img_test = tc.zeros((10000, 784, 2), dtype=data_type, device=device)
    img_train[:, :, 0] = tc.cos(img_train1)
    img_train[:, :, 1] = tc.sin(img_train1)
    img_test[:, :, 0] = tc.cos(img_test1)
    img_test[:, :, 1] = tc.sin(img_test1)
    label_train = tc.squeeze(tc.tensor(label_train, dtype=tc.long, device=device))
    label_test = tc.squeeze(tc.tensor(label_test, dtype=tc.long, device=device))
    return img_train, img_test, label_train, label_test


def cul_test_acc_rlf(batch_num, known_picture_list, unknown_picture, base, device, label_test):
    total_num = unknown_picture.shape[0]
    circle_num = total_num // batch_num  # 正常循环次数
    yushu = total_num % batch_num  # 剩下的
    if total_num % batch_num != 0:
        inner_product = tc.zeros((len(known_picture_list), total_num - yushu), dtype=tc.float64, device=device)
        for i in range(circle_num):
            for ii in range(len(known_picture_list)):
                inner_product0 = tc.einsum('nld, mld-> nml', [unknown_picture[(i * batch_num):(i + 1) * batch_num, :, :], known_picture_list[ii]])
                inner_product_1 = tc.log10(inner_product0 + 1e-7)
                inner_product_1 = tc.einsum('nml-> nm', [inner_product_1])
                inner_product_1 = base ** inner_product_1
                inner_product[ii:, (i * batch_num):(i + 1) * batch_num] = tc.einsum('nm-> n', [inner_product_1]) / known_picture_list[ii].shape[0]
        # 计算剩余部分
        yushu_tensor = tc.zeros((len(known_picture_list), yushu), dtype=tc.float64, device=device)
        for iii in range(len(known_picture_list)):
            inner_product00 = tc.einsum('nld, mld-> nml', [unknown_picture[(total_num - yushu):, :, :], known_picture_list[iii]])
            inner_product_yushu = tc.log10(inner_product00 + 1e-7)
            inner_product_yushu = tc.einsum('nml-> nm', [inner_product_yushu])
            inner_product_yushu = base ** inner_product_yushu
            inner_product_yushu = tc.einsum('nm-> n', [inner_product_yushu]) / known_picture_list[iii].shape[0]

            yushu_tensor[iii, :] = inner_product_yushu
        inner_product = tc.cat((inner_product, yushu_tensor), dim=1)
    else:
        inner_product = tc.zeros((len(known_picture_list), total_num), dtype=tc.float64, device=device)
        for i in range(circle_num):
            for ii in range(len(known_picture_list)):
                inner_product0 = tc.einsum('nld, mld-> nml', [unknown_picture[(i * batch_num):(i + 1) * batch_num, :, :], known_picture_list[ii]])
                inner_product_yushu = tc.log10(inner_product0 + 1e-9)
                inner_product_yushu = tc.einsum('nml-> nm', [inner_product_yushu])
                inner_product_yushu = base ** inner_product_yushu
                inner_product[ii:, (i * batch_num):(i + 1) * batch_num] = tc.einsum('nm-> n', [inner_product_yushu]) / known_picture_list[ii].shape[0]
    lable_unknown_guess = tc.argmax(inner_product, dim=0)
    acu_test = round(tc.sum((lable_unknown_guess == label_test), dim=0).item() / label_test.shape[0], 5)
    print('test_acc：', acu_test)
    return acu_test


def select_data(lab, img, num):
    other_picture_index_list = []
    center_given = []
    for i in range(10):
        a = (tc.squeeze((lab == i).nonzero(), dim=1)).type(tc.long)
        random_number = set(sample(range(a.shape[0]), num))
        random_number_list = list(random_number)

        means_vectors_index = a[random_number_list]
        list_all_picture = set(range(a.shape[0]))

        other_picture_index = list(list_all_picture - random_number)

        center_given.append(img[means_vectors_index])
        other_picture_index_list = other_picture_index_list + other_picture_index

    unlabel_pictures = img[other_picture_index_list]
    unlabel_pictures_ture_label = lab[other_picture_index_list]
    return center_given, unlabel_pictures, unlabel_pictures_ture_label


batch_num = 200
base = 1.9
device = 'cuda:0'
data_type = tc.float32
nor = 510
train_sample_num = 30

img_train, label_train, img_test, label_test = load_data()
img_train, img_test, label_train, label_test = feature_map(img_train, img_test, label_train, label_test, nor, data_type, device)
img_train_list = select_data(label_train, img_train, train_sample_num)[0]
acu_test = cul_test_acc_rlf(batch_num, img_train_list, img_test, base, device, label_test)

