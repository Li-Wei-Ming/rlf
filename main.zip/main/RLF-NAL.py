import RNfunction as ssf
import numpy as np
import torch as tc
from RNfunction import Semi
from random import sample
img_train, label_train, img_test, label_test = ssf.load_data()

add_num = 500
data_type_list = [tc.float32, tc.float64, tc.float64]
base_list = [1.3, 1.3]
device = 'cuda:0'
circle_num = 12
batch_num = 200
delete_para_list, delete_mode = [add_num, 0.2], 1
update_para_list = [1, 2]
choose_num_first = 10

semi = Semi(img_train, label_train, choose_num_first, add_num, data_type_list, base_list, device, circle_num, batch_num, delete_para_list, delete_mode, update_para_list,  img_test, label_test)
semi.__main__()

